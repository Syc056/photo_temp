import React from 'react';

function Body() {
  return (
    <div className="body">
      <div className="column col1">Column 1</div>
      <div className="column col2"></div>
      <div className="column col3">Column 3</div>
    </div>
  );
}

export default Body;
